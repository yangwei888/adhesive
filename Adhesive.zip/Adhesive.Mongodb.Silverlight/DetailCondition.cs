﻿
namespace Adhesive.Mongodb.Silverlight
{
    public class DetailCondition
    {
        public string DatabasePrefix { get; set; }

        public string DatabaseName { get; set; }

        public string TableName { get; set; }

        public string PkColumnName { get; set; }

        public string ID { get; set; }
    }
}
